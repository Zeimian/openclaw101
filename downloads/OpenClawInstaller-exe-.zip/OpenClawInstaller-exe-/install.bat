@echo off
title OpenClaw Installer
echo.
echo  ========================================
echo    OpenClaw Installer is starting...
echo  ========================================
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0OpenClawInstaller.ps1"
if errorlevel 1 (
    echo.
    echo  Failed to start! Please try right-click and "Run as Administrator".
    echo.
    pause
)
