﻿# OpenClaw 一键安装器
# 支持自动检测环境、安装 Node.js、安装 OpenClaw 及渠道插件（飞书/QQ Bot）、配置国内 AI 模型

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ==================== 全局变量 ====================

$script:useWSL = $false
$script:gatewayProcess = $null

$script:permissionsJSON = @'
{
  "scopes": {
    "tenant": [
      "im:message",
      "im:message:send_as_bot",
      "im:message.group_at_msg:readonly",
      "im:message.p2p_msg:readonly",
      "im:chat",
      "im:chat:readonly",
      "im:chat.members:bot_access",
      "contact:contact.base:readonly",
      "docs:document.content:read",
      "sheets:spreadsheet"
    ]
  }
}
'@

$script:ModelProviders = @(
    @{
        Name     = "DeepSeek (推荐，性价比最高)"
        Provider = "deepseek"
        Model    = "deepseek/deepseek-chat"
        Url      = "https://platform.deepseek.com/api_keys"
        Tip      = "国内首选，价格极低，效果优秀"
        AuthMode = "api_key"
    },
    @{
        Name     = "通义千问 Qwen (每天2000次免费)"
        Provider = "qwen-portal"
        Model    = "qwen-portal/coder-model"
        Url      = "https://bailian.console.aliyun.com/"
        Tip      = "阿里云出品，有免费额度，需 OAuth 设备码登录"
        AuthMode = "oauth"
    },
    @{
        Name     = "智谱 GLM (ChatGLM)"
        Provider = "zai"
        Model    = "zai/glm-4.7"
        Url      = "https://open.bigmodel.cn/usercenter/apikeys"
        Tip      = "清华系大模型，GLM-4 系列"
        AuthMode = "api_key"
    },
    @{
        Name     = "Moonshot Kimi"
        Provider = "moonshot"
        Model    = "moonshot/kimi-k2.5"
        Url      = "https://platform.moonshot.cn/console/api-keys"
        Tip      = "月之暗面出品，Kimi 大模型"
        AuthMode = "api_key"
    },
    @{
        Name     = "MiniMax (有免费 Coding Plan)"
        Provider = "minimax"
        Model    = "minimax/MiniMax-M2.1"
        Url      = "https://platform.minimaxi.com/user-center/basic-information/interface-key"
        Tip      = "MiniMax 出品，提供免费编程额度"
        AuthMode = "api_key"
    },
    @{
        Name     = "OpenAI (需科学上网)"
        Provider = "openai"
        Model    = "openai/gpt-4o"
        Url      = "https://platform.openai.com/api-keys"
        Tip      = "需海外网络环境和付费账号"
        AuthMode = "api_key"
    }
)

# ==================== 颜色主题 ====================

$script:Colors = @{
    Primary   = [System.Drawing.Color]::FromArgb(30, 58, 95)
    Accent    = [System.Drawing.Color]::FromArgb(33, 150, 243)
    Success   = [System.Drawing.Color]::FromArgb(76, 175, 80)
    Warning   = [System.Drawing.Color]::FromArgb(255, 152, 0)
    Error     = [System.Drawing.Color]::FromArgb(244, 67, 54)
    BgLight   = [System.Drawing.Color]::FromArgb(245, 247, 250)
    BgDark    = [System.Drawing.Color]::FromArgb(30, 30, 46)
    TextLight = [System.Drawing.Color]::FromArgb(200, 220, 240)
    LogGreen  = [System.Drawing.Color]::FromArgb(80, 250, 123)
    LogYellow = [System.Drawing.Color]::FromArgb(241, 250, 140)
    LogRed    = [System.Drawing.Color]::FromArgb(255, 85, 85)
}

# ==================== 辅助函数 ====================

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "HH:mm:ss"
    $color = switch ($Level) {
        "INFO"    { $script:Colors.LogGreen }
        "WARN"    { $script:Colors.LogYellow }
        "ERROR"   { $script:Colors.LogRed }
        "SUCCESS" { $script:Colors.Success }
        default   { $script:Colors.TextLight }
    }
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.SelectionLength = 0
    $logBox.SelectionColor = [System.Drawing.ColorTranslator]::FromHtml("#6272a4")
    $logBox.AppendText("[$timestamp] ")
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.SelectionColor = $color
    $logBox.AppendText("$Message`r`n")
    $logBox.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

function Run-Command {
    param([string]$Command, [switch]$Silent)
    $tempOut = [System.IO.Path]::GetTempFileName()
    $tempErr = [System.IO.Path]::GetTempFileName()
    try {
        if ($script:useWSL) {
            $proc = Start-Process -FilePath "wsl" `
                -ArgumentList "-e", "bash", "-c", $Command `
                -NoNewWindow -PassThru `
                -RedirectStandardOutput $tempOut `
                -RedirectStandardError $tempErr
        } else {
            # 使用 ProcessStartInfo 确保子进程继承最新的 PATH
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = "cmd.exe"
            $psi.Arguments = "/c $Command"
            $psi.UseShellExecute = $false
            $psi.RedirectStandardOutput = $true
            $psi.RedirectStandardError = $true
            $psi.CreateNoWindow = $true
            $psi.EnvironmentVariables["Path"] = $env:Path
            $procObj = New-Object System.Diagnostics.Process
            $procObj.StartInfo = $psi
            $procObj.Start() | Out-Null
            $stdoutTask = $procObj.StandardOutput.ReadToEndAsync()
            $stderrTask = $procObj.StandardError.ReadToEndAsync()
            while (-not $procObj.HasExited) {
                [System.Windows.Forms.Application]::DoEvents()
                Start-Sleep -Milliseconds 100
            }
            $procObj.WaitForExit()
            $stdout = $stdoutTask.Result
            $stderr = $stderrTask.Result

            if ($stdout) { $stdout | Out-File -FilePath $tempOut -Encoding UTF8 -Force }
            if ($stderr) { $stderr | Out-File -FilePath $tempErr -Encoding UTF8 -Force }

            if (-not $Silent -and $stdout) {
                foreach ($line in ($stdout -split "`n")) {
                    $trimmed = $line.Trim()
                    if ($trimmed) { Write-Log "  $trimmed" }
                }
            }
            return @{ Success = ($procObj.ExitCode -eq 0); Output = $stdout; Error = $stderr; ExitCode = $procObj.ExitCode }
        }
        while (-not $proc.HasExited) {
            [System.Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 100
        }
        $stdout = if (Test-Path $tempOut) { Get-Content $tempOut -Raw -Encoding UTF8 -ErrorAction SilentlyContinue } else { "" }
        $stderr = if (Test-Path $tempErr) { Get-Content $tempErr -Raw -Encoding UTF8 -ErrorAction SilentlyContinue } else { "" }
        if (-not $Silent -and $stdout) {
            foreach ($line in ($stdout -split "`n")) {
                $trimmed = $line.Trim()
                if ($trimmed) { Write-Log "  $trimmed" }
            }
        }
        return @{ Success = ($proc.ExitCode -eq 0); Output = $stdout; Error = $stderr; ExitCode = $proc.ExitCode }
    } catch {
        if (-not $Silent) { Write-Log "  命令执行异常: $_" "ERROR" }
        return @{ Success = $false; Output = ""; Error = $_.Exception.Message; ExitCode = 1 }
    } finally {
        Remove-Item $tempOut, $tempErr -Force -ErrorAction SilentlyContinue
    }
}

function Update-StatusLabel {
    param([System.Windows.Forms.Label]$Label, [bool]$OK, [string]$TextOK, [string]$TextFail)
    if ($OK) {
        $Label.Text = "  $TextOK"
        $Label.ForeColor = $script:Colors.Success
    } else {
        $Label.Text = "  $TextFail"
        $Label.ForeColor = $script:Colors.Error
    }
}

# ==================== 检测函数 ====================

function Test-WSL {
    # 始终在 Windows 原生环境中执行，不经过 Run-Command
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = "wsl"
        $psi.Arguments = "--status"
        $psi.UseShellExecute = $false
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.CreateNoWindow = $true
        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi
        $proc.Start() | Out-Null
        $null = $proc.WaitForExit(8000)
        return ($proc.ExitCode -eq 0)
    } catch {
        return $false
    }
}

function Refresh-EnvPath {
    $machinePath = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath"

    $searchDirs = @(
        "$env:ProgramFiles\nodejs",
        "${env:ProgramFiles(x86)}\nodejs",
        "$env:LOCALAPPDATA\Programs\nodejs",
        "C:\Program Files\nodejs",
        "C:\nodejs"
    )
    foreach ($dir in $searchDirs) {
        if ((Test-Path (Join-Path $dir "node.exe")) -and ($env:Path -notlike "*$dir*")) {
            $env:Path = "$dir;$env:Path"
            break
        }
    }
}

function Get-NodeInfoForMode {
    param([bool]$WSLMode)
    $oldUseWSL = $script:useWSL
    $script:useWSL = $WSLMode
    try {
        if (-not $WSLMode) { Refresh-EnvPath }

        $r = Run-Command "node --version" -Silent
        if ($r.Success -and $r.Output -match "v(\d+)") {
            return @{ Installed = $true; Version = $r.Output.Trim(); Major = [int]$Matches[1] }
        }

        # 非 WSL 模式下，回退搜索文件系统
        if (-not $WSLMode) {
            $searchDirs = @(
                "$env:ProgramFiles\nodejs",
                "${env:ProgramFiles(x86)}\nodejs",
                "$env:LOCALAPPDATA\Programs\nodejs",
                "C:\Program Files\nodejs"
            )
            foreach ($dir in $searchDirs) {
                $nodeExe = Join-Path $dir "node.exe"
                if (Test-Path $nodeExe) {
                    $env:Path = "$dir;$env:Path"
                    $r2 = Run-Command "`"$nodeExe`" --version" -Silent
                    if ($r2.Success -and $r2.Output -match "v(\d+)") {
                        return @{ Installed = $true; Version = $r2.Output.Trim(); Major = [int]$Matches[1] }
                    }
                }
            }
        }
        return @{ Installed = $false; Version = ""; Major = 0 }
    } finally {
        $script:useWSL = $oldUseWSL
    }
}

function Get-NodeInfo {
    return Get-NodeInfoForMode -WSLMode $script:useWSL
}

function Get-OpenClawInfo {
    $r = Run-Command "openclaw --version" -Silent
    if ($r.Success -and $r.Output) { return @{ Installed = $true; Version = $r.Output.Trim() } }
    return @{ Installed = $false; Version = "" }
}

function Test-FeishuPlugin {
    $r = Run-Command "openclaw plugins list" -Silent
    return ($r.Success -and $r.Output -match "feishu")
}

function Test-QQBotPlugin {
    $r = Run-Command "openclaw plugins list" -Silent
    return ($r.Success -and $r.Output -match "qqbot")
}

function Install-QQBotPlugin {
    Write-Log ">>> 正在安装 QQ Bot 插件 ..." "INFO"
    $r = Run-Command "openclaw plugins install @sliverp/qqbot@latest"
    $ok = Test-QQBotPlugin
    if ($ok) {
        Write-Log "QQ Bot 插件安装成功！" "SUCCESS"
        Update-StatusLabel $lblQQBot $true "已安装" ""
        return $true
    } else {
        Write-Log "QQ Bot 插件安装失败" "ERROR"
        return $false
    }
}

function Do-EnvironmentCheck {
    $btnCheck.Enabled = $false
    $btnInstall.Enabled = $false
    # 每次检测前重置状态
    $script:useWSL = $false
    Write-Log "====== 开始环境检测 ======" "INFO"

    # 1. WSL 检测（始终在 Windows 原生执行）
    $wslOK = Test-WSL

    # 2. 分别检测两种环境下的 Node.js
    $winNodeInfo = Get-NodeInfoForMode -WSLMode $false
    $wslNodeInfo = @{ Installed = $false; Version = ""; Major = 0 }
    if ($wslOK) {
        $wslNodeInfo = Get-NodeInfoForMode -WSLMode $true
    }

    # 3. 智能选择运行模式
    $winNodeOK = ($winNodeInfo.Installed -and $winNodeInfo.Major -ge 22)
    $wslNodeOK = ($wslNodeInfo.Installed -and $wslNodeInfo.Major -ge 22)

    if ($wslOK -and $wslNodeOK) {
        $script:useWSL = $true
        Write-Log "WSL2 可用，WSL 中 Node.js $($wslNodeInfo.Version) 就绪，使用 WSL 模式" "SUCCESS"
    } elseif ($wslOK -and $winNodeOK) {
        $script:useWSL = $false
        Write-Log "WSL2 可用，但 Node.js 仅在 Windows 上，使用 Windows 原生模式" "INFO"
    } elseif ($wslOK) {
        $script:useWSL = $false
        Write-Log "WSL2 可用，但两侧均无 Node.js，将使用 Windows 原生模式安装" "INFO"
    } else {
        $script:useWSL = $false
        Write-Log "WSL2 未检测到，使用 Windows 原生模式" "WARN"
    }
    Update-StatusLabel $lblWSL $wslOK "WSL2 已就绪" "WSL2 未安装 (原生模式)"

    # 4. 用选定的模式显示 Node.js 状态
    $nodeInfo = if ($script:useWSL) { $wslNodeInfo } else { $winNodeInfo }
    if ($nodeInfo.Installed) {
        $vOK = $nodeInfo.Major -ge 22
        if ($vOK) { Write-Log "Node.js $($nodeInfo.Version) 版本符合要求" "SUCCESS" }
        else { Write-Log "Node.js $($nodeInfo.Version) 版本过低，需要 v22+" "WARN" }
        Update-StatusLabel $lblNode $vOK "Node.js $($nodeInfo.Version)" "Node.js $($nodeInfo.Version) (需 v22+)"
    } else {
        Write-Log "Node.js 未安装" "WARN"
        Update-StatusLabel $lblNode $false "" "未安装"
    }

    # 5. OpenClaw 和飞书插件
    $ocInfo = Get-OpenClawInfo
    if ($ocInfo.Installed) { Write-Log "OpenClaw $($ocInfo.Version) 已安装" "SUCCESS" }
    else { Write-Log "OpenClaw 未安装" "WARN" }
    Update-StatusLabel $lblOpenClaw $ocInfo.Installed "OpenClaw $($ocInfo.Version)" "未安装"

    $feishuOK = $false
    $qqbotOK = $false
    if ($ocInfo.Installed) {
        $feishuOK = Test-FeishuPlugin
        if ($feishuOK) { Write-Log "飞书插件已安装" "SUCCESS" }
        else { Write-Log "飞书插件未安装" "WARN" }
        $qqbotOK = Test-QQBotPlugin
        if ($qqbotOK) { Write-Log "QQ Bot 插件已安装" "SUCCESS" }
        else { Write-Log "QQ Bot 插件未安装" "WARN" }
    }
    Update-StatusLabel $lblFeishu $feishuOK "已安装" "未安装"
    Update-StatusLabel $lblQQBot $qqbotOK "已安装" "未安装"

    Write-Log "====== 环境检测完成 (模式: $(if ($script:useWSL) {'WSL'} else {'Windows'})) ======" "INFO"
    $btnCheck.Enabled = $true
    $btnInstall.Enabled = $true
}

# ==================== 安装函数 ====================

function Install-NodeJS {
    Write-Log ">>> 正在安装 Node.js 22 LTS ..." "INFO"
    if ($script:useWSL) {
        Write-Log "通过 WSL 安装 Node.js (NodeSource) ..." "INFO"
        Run-Command "curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -"
        Run-Command "sudo apt-get install -y nodejs"
    } else {
        $wingetOK = $false
        try { $wr = Run-Command "winget --version" -Silent; $wingetOK = $wr.Success } catch {}

        if ($wingetOK) {
            Write-Log "使用 winget 安装 Node.js ..." "INFO"
            $r = Run-Command "winget install OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements"
            if (-not $r.Success) {
                Write-Log "winget 安装失败，尝试手动下载..." "WARN"
                Install-NodeJSManual
            }
        } else {
            Write-Log "winget 不可用，使用手动下载 ..." "INFO"
            Install-NodeJSManual
        }
    }

    # 等待安装程序完成注册表更新
    Write-Log "等待安装完成..." "INFO"
    for ($retry = 1; $retry -le 5; $retry++) {
        Start-Sleep -Seconds 2
        [System.Windows.Forms.Application]::DoEvents()

        Refresh-EnvPath
        $nodeInfo = Get-NodeInfo

        if ($nodeInfo.Installed -and $nodeInfo.Major -ge 22) {
            Write-Log "Node.js $($nodeInfo.Version) 安装成功！" "SUCCESS"
            Update-StatusLabel $lblNode $true "Node.js $($nodeInfo.Version)" ""
            return $true
        }
        Write-Log "  第 $retry 次检测... 尚未就绪" "INFO"
    }

    # 最后尝试：搜索文件系统
    Write-Log "正在搜索 Node.js 安装位置..." "WARN"
    $found = $false
    $searchDirs = @(
        "$env:ProgramFiles\nodejs",
        "${env:ProgramFiles(x86)}\nodejs",
        "$env:LOCALAPPDATA\Programs\nodejs",
        "C:\Program Files\nodejs"
    )
    foreach ($dir in $searchDirs) {
        $nodeExe = Join-Path $dir "node.exe"
        if (Test-Path $nodeExe) {
            Write-Log "  在 $dir 找到 node.exe" "SUCCESS"
            $env:Path = "$dir;$env:Path"
            $found = $true
            break
        }
    }

    if ($found) {
        $nodeInfo = Get-NodeInfo
        if ($nodeInfo.Installed -and $nodeInfo.Major -ge 22) {
            Write-Log "Node.js $($nodeInfo.Version) 安装成功！" "SUCCESS"
            Update-StatusLabel $lblNode $true "Node.js $($nodeInfo.Version)" ""
            return $true
        }
    }

    Write-Log "Node.js 安装后验证失败" "ERROR"
    Write-Log "可能的解决方案：" "WARN"
    Write-Log "  1. 关闭安装器，重新打开后再次检测环境" "WARN"
    Write-Log "  2. 手动从 https://nodejs.org 下载安装 Node.js 22 LTS" "WARN"
    Write-Log "  3. 安装完成后重启电脑再运行安装器" "WARN"
    return $false
}

function Install-NodeJSManual {
    Write-Log "正在从 Node.js 官网下载安装包 ..." "INFO"
    $arch = if ([System.Environment]::Is64BitOperatingSystem) { "x64" } else { "x86" }
    $url = "https://nodejs.org/dist/v22.14.0/node-v22.14.0-$arch.msi"
    $msiPath = Join-Path $env:TEMP "nodejs_installer.msi"
    try {
        Write-Log "  下载: $url" "INFO"

        $wc = New-Object System.Net.WebClient
        $downloadComplete = $false
        $wc.Add_DownloadProgressChanged({
            param($s, $e)
            if ($e.ProgressPercentage % 20 -eq 0) {
                [System.Windows.Forms.Application]::DoEvents()
            }
        })
        $wc.DownloadFile($url, $msiPath)
        Write-Log "  下载完成 ($('{0:N1}' -f ((Get-Item $msiPath).Length / 1MB)) MB)" "SUCCESS"

        # 先尝试静默安装（需要管理员权限）
        Write-Log "  正在安装（可能弹出 UAC 授权提示，请点击「是」）..." "INFO"
        try {
            $proc = Start-Process -FilePath "msiexec.exe" `
                -ArgumentList "/i", "`"$msiPath`"", "/qn", "/norestart" `
                -Wait -PassThru -Verb RunAs
            while (-not $proc.HasExited) {
                [System.Windows.Forms.Application]::DoEvents()
                Start-Sleep -Milliseconds 200
            }
            if ($proc.ExitCode -eq 0) {
                Write-Log "  MSI 静默安装完成" "SUCCESS"
                return
            }
            Write-Log "  静默安装失败 (代码 $($proc.ExitCode))，切换为图形安装" "WARN"
        } catch {
            Write-Log "  静默安装失败（可能未授权管理员权限），切换为图形安装" "WARN"
        }

        # 回退：打开图形化安装界面让用户手动操作
        Write-Log "  正在打开 Node.js 图形安装界面，请按提示完成安装" "WARN"
        Write-Log "  安装完成后请回到此窗口" "WARN"
        $proc2 = Start-Process -FilePath "msiexec.exe" `
            -ArgumentList "/i", "`"$msiPath`"" `
            -PassThru
        while (-not $proc2.HasExited) {
            [System.Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 300
        }
        if ($proc2.ExitCode -eq 0) {
            Write-Log "  Node.js 图形化安装已完成" "SUCCESS"
        } else {
            Write-Log "  安装程序退出代码: $($proc2.ExitCode)" "WARN"
        }
    } catch {
        Write-Log "  下载或安装失败: $_" "ERROR"
        Write-Log "  请手动访问 https://nodejs.org 下载 Node.js 22 LTS" "WARN"

        $openBrowser = [System.Windows.Forms.MessageBox]::Show(
            "自动下载失败。是否打开浏览器手动下载 Node.js？",
            "下载失败", "YesNo", "Question"
        )
        if ($openBrowser -eq "Yes") {
            Start-Process "https://nodejs.org/zh-cn/download/"
            Write-Log "  已打开 Node.js 下载页面，请下载并安装后重新运行安装器" "INFO"
        }
    } finally {
        Remove-Item $msiPath -Force -ErrorAction SilentlyContinue
    }
}

function Setup-NpmPaths {
    if ($script:useWSL) { return }

    # 将 npm 全局安装目录和缓存目录设到用户目录下，避免 C:\Program Files 的权限问题
    $npmGlobalDir = Join-Path $env:APPDATA "npm"
    $npmCacheDir = Join-Path $env:APPDATA "npm-cache"

    if (-not (Test-Path $npmGlobalDir)) { New-Item -Path $npmGlobalDir -ItemType Directory -Force | Out-Null }
    if (-not (Test-Path $npmCacheDir)) { New-Item -Path $npmCacheDir -ItemType Directory -Force | Out-Null }

    Write-Log "配置 npm 全局路径: $npmGlobalDir" "INFO"
    Run-Command "npm config set prefix `"$npmGlobalDir`"" -Silent
    Run-Command "npm config set cache `"$npmCacheDir`"" -Silent

    # 将 npm 全局 bin 目录加入 PATH
    if ($env:Path -notlike "*$npmGlobalDir*") {
        $env:Path = "$npmGlobalDir;$env:Path"
    }

    # 持久化到用户 PATH（下次打开终端也能找到 openclaw）
    $userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
    if ($userPath -notlike "*$npmGlobalDir*") {
        [System.Environment]::SetEnvironmentVariable("Path", "$npmGlobalDir;$userPath", "User")
        Write-Log "已将 $npmGlobalDir 添加到用户 PATH" "INFO"
    }
}

function Test-PortOpen {
    param([string]$Host_, [int]$Port, [int]$TimeoutMs = 2000)
    try {
        $tcp = New-Object System.Net.Sockets.TcpClient
        $ar = $tcp.BeginConnect($Host_, $Port, $null, $null)
        $ok = $ar.AsyncWaitHandle.WaitOne($TimeoutMs)
        $tcp.Close()
        return $ok
    } catch { return $false }
}

function Setup-GitForChina {
    Write-Log "配置 git 网络环境（国内优化）..." "INFO"
    try {
        # ========== 1. SSH → HTTPS 转换 ==========
        & git config --global "url.https://github.com/.insteadOf" "ssh://git@github.com/"
        & git config --global --add "url.https://github.com/.insteadOf" "git@github.com:"
        Write-Log "  已配置 SSH → HTTPS 转换" "INFO"

        # ========== 2. 全面清理无效代理 ==========
        $savedProxy = $null

        # 2a. 扫描 git config 所有级别的代理项（global + system + URL-specific）
        $gitConfigLines = & git config --list --show-origin 2>$null
        if ($gitConfigLines) {
            $proxyEntries = $gitConfigLines | Where-Object { $_ -match "proxy" }
            foreach ($entry in $proxyEntries) {
                if ($entry -match "127\.0\.0\.1|localhost|socks5?://") {
                    if ($entry -match ":(\d+)") {
                        $port = [int]$Matches[1]
                        $alive = Test-PortOpen "127.0.0.1" $port
                        if (-not $alive) {
                            # 提取 key（如 http.proxy 或 http.https://github.com.proxy）
                            if ($entry -match "\t(.+?)=(.+)$") {
                                $key = $Matches[1]
                                $val = $Matches[2]
                                if (-not $savedProxy) { $savedProxy = $val }
                                Write-Log "  发现无效代理: $key = $val" "WARN"
                                & git config --global --unset-all $key 2>$null
                                Write-Log "  已清除: $key" "SUCCESS"
                            }
                        } else {
                            Write-Log "  代理 $entry 可用，保留" "INFO"
                        }
                    }
                }
            }
        }

        # 2b. 清理环境变量中的代理
        $envProxyVars = @("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy", "ALL_PROXY", "all_proxy")
        foreach ($var in $envProxyVars) {
            $val = [System.Environment]::GetEnvironmentVariable($var)
            if ($val -and $val -match "127\.0\.0\.1|localhost") {
                if ($val -match ":(\d+)") {
                    $port = [int]$Matches[1]
                    if (-not (Test-PortOpen "127.0.0.1" $port)) {
                        Write-Log "  清除环境变量: $var = $val" "WARN"
                        [System.Environment]::SetEnvironmentVariable($var, $null)
                        if (-not $savedProxy) { $savedProxy = $val }
                    }
                }
            }
        }

        # 2c. 清理 npm 代理
        foreach ($npmKey in @("proxy", "https-proxy")) {
            $val = & npm config get $npmKey 2>$null
            if ($val -and $val -ne "null" -and $val -ne "undefined" -and $val -match "127\.0\.0\.1|localhost") {
                if ($val -match ":(\d+)") {
                    $port = [int]$Matches[1]
                    if (-not (Test-PortOpen "127.0.0.1" $port)) {
                        & npm config delete $npmKey 2>$null
                        Write-Log "  清除 npm $npmKey = $val" "SUCCESS"
                    }
                }
            }
        }

        if ($savedProxy) {
            Write-Log "  所有无效代理已清除" "SUCCESS"
            Write-Log "  恢复方法：开启 VPN 后执行 git config --global http.proxy $savedProxy" "INFO"
        }

        # ========== 3. 测试 GitHub 连通性 ==========
        Write-Log "  测试 GitHub 连通性 ..." "INFO"
        $testOK = $false
        try {
            $req = [System.Net.HttpWebRequest]::Create("https://github.com")
            $req.Timeout = 8000
            $req.Method = "HEAD"
            $req.Proxy = [System.Net.GlobalProxySelection]::GetEmptyWebProxy()
            $resp = $req.GetResponse()
            $resp.Close()
            $testOK = $true
        } catch {}

        if ($testOK) {
            Write-Log "  GitHub 直连可用" "SUCCESS"
        } else {
            Write-Log "  GitHub 直连不可用，配置加速代理 ..." "WARN"
            $proxyUrls = @(
                "https://ghfast.top/https://github.com/",
                "https://ghp.ci/https://github.com/",
                "https://github.moeyy.xyz/https://github.com/"
            )
            $proxySet = $false
            foreach ($proxy in $proxyUrls) {
                try {
                    $testUrl = $proxy -replace "https://github.com/$", "https://github.com/robots.txt"
                    $req = [System.Net.HttpWebRequest]::Create($testUrl)
                    $req.Timeout = 8000
                    $req.Method = "HEAD"
                    $req.Proxy = [System.Net.GlobalProxySelection]::GetEmptyWebProxy()
                    $resp = $req.GetResponse()
                    $resp.Close()

                    & git config --global "url.$proxy.insteadOf" "https://github.com/"
                    Write-Log "  已配置 GitHub 加速代理: $proxy" "SUCCESS"
                    $proxySet = $true
                    break
                } catch {
                    Write-Log "  代理 $proxy 不可用，尝试下一个..." "WARN"
                }
            }
            if (-not $proxySet) {
                Write-Log "  所有加速代理均不可用" "WARN"
                Write-Log "  建议：开启 Clash/VPN 后重试" "WARN"
            }
        }
    } catch {
        Write-Log "  git 配置异常: $_" "WARN"
    }
}

function Install-OpenClaw {
    Write-Log ">>> 正在安装 OpenClaw ..." "INFO"

    # 配置 git 网络（SSH→HTTPS + 国内加速代理）
    Setup-GitForChina

    # 配置 npm（镜像源 + 用户目录）
    Write-Log "配置 npm 国内镜像源 ..." "INFO"
    Run-Command "npm config set registry https://registry.npmmirror.com" -Silent
    Setup-NpmPaths

    Write-Log "执行: npm install -g openclaw@latest" "INFO"
    $r = Run-Command "npm install -g openclaw@latest"

    # 安装后刷新 PATH
    Refresh-EnvPath
    $npmBin = Join-Path $env:APPDATA "npm"
    if ($env:Path -notlike "*$npmBin*") { $env:Path = "$npmBin;$env:Path" }

    $ocInfo = Get-OpenClawInfo
    if ($ocInfo.Installed) {
        Write-Log "OpenClaw $($ocInfo.Version) 安装成功！" "SUCCESS"
        Update-StatusLabel $lblOpenClaw $true "OpenClaw $($ocInfo.Version)" ""
        return $true
    }

    # 可能是 PATH 问题，搜索常见安装位置
    $possiblePaths = @(
        (Join-Path $env:APPDATA "npm"),
        (Join-Path $env:APPDATA "npm\node_modules\.bin"),
        "$env:ProgramFiles\nodejs",
        "$env:ProgramFiles\nodejs\node_modules\.bin"
    )
    foreach ($p in $possiblePaths) {
        if ((Test-Path (Join-Path $p "openclaw.cmd")) -or (Test-Path (Join-Path $p "openclaw"))) {
            if ($env:Path -notlike "*$p*") { $env:Path = "$p;$env:Path" }
        }
    }
    $ocInfo = Get-OpenClawInfo
    if ($ocInfo.Installed) {
        Write-Log "OpenClaw $($ocInfo.Version) 安装成功！" "SUCCESS"
        Update-StatusLabel $lblOpenClaw $true "OpenClaw $($ocInfo.Version)" ""
        return $true
    }

    Write-Log "OpenClaw 安装失败" "ERROR"
    if ($r.Error) { Write-Log "  错误: $($r.Error)" "ERROR" }
    return $false
}

function Install-FeishuPlugin {
    Write-Log ">>> 正在安装飞书插件 ..." "INFO"
    $r = Run-Command "openclaw plugins install @openclaw/feishu"
    $ok = Test-FeishuPlugin
    if ($ok) {
        Write-Log "飞书插件安装成功！" "SUCCESS"
        Update-StatusLabel $lblFeishu $true "已安装" ""
        return $true
    } else {
        Write-Log "飞书插件安装失败" "ERROR"
        return $false
    }
}

function Set-Progress {
    param([int]$Value, [string]$Text)
    $progressBar.Value = $Value
    $lblProgress.Text = "$Value%  $Text"
    [System.Windows.Forms.Application]::DoEvents()
}

function Do-OneClickInstall {
    $btnInstall.Enabled = $false
    $btnCheck.Enabled = $false
    $progressBar.Value = 0
    $progressBar.Visible = $true
    $lblProgress.Visible = $true

    Write-Log "============================================" "INFO"
    Write-Log "    开始一键安装 OpenClaw + QQ Bot 插件" "INFO"
    Write-Log "============================================" "INFO"

    Set-Progress 5 "检测 Node.js..."
    $nodeInfo = Get-NodeInfo
    if ($nodeInfo.Installed -and $nodeInfo.Major -ge 22) {
        Write-Log "Node.js $($nodeInfo.Version) 已就绪" "SUCCESS"
        Set-Progress 15 "Node.js 就绪"
    } else {
        Set-Progress 10 "安装 Node.js..."
        if (-not (Install-NodeJS)) {
            Write-Log "Node.js 安装失败，中止" "ERROR"
            $btnInstall.Enabled = $true; $btnCheck.Enabled = $true
            $progressBar.Visible = $false; $lblProgress.Visible = $false
            return
        }
        Set-Progress 30 "Node.js 完成"
    }

    Set-Progress 35 "安装 OpenClaw..."
    $ocInfo = Get-OpenClawInfo
    if ($ocInfo.Installed) {
        Write-Log "OpenClaw 已安装，检查更新..." "INFO"
        Run-Command "npm update -g openclaw" -Silent
        Set-Progress 65 "OpenClaw 就绪"
    } else {
        if (-not (Install-OpenClaw)) {
            Write-Log "OpenClaw 安装失败，中止" "ERROR"
            $btnInstall.Enabled = $true; $btnCheck.Enabled = $true
            $progressBar.Visible = $false; $lblProgress.Visible = $false
            return
        }
        Set-Progress 65 "OpenClaw 完成"
    }

    Set-Progress 70 "安装 QQ Bot..."
    if (Test-QQBotPlugin) {
        Write-Log "QQ Bot 插件已安装" "SUCCESS"
    } else {
        Install-QQBotPlugin | Out-Null
    }

    Set-Progress 100 "安装完成！"

    $ocInfo = Get-OpenClawInfo
    if ($ocInfo.Installed) {
        Update-StatusLabel $lblOpenClaw $true "OpenClaw $($ocInfo.Version)" ""
    }
    if (Test-QQBotPlugin) {
        Update-StatusLabel $lblQQBot $true "已安装" ""
    }
    if (Test-FeishuPlugin) {
        Update-StatusLabel $lblFeishu $true "已安装" ""
    }

    Write-Log "============================================" "SUCCESS"
    Write-Log "  安装完成！" "SUCCESS"
    Write-Log "============================================" "SUCCESS"
    Write-Log "" "INFO"
    Write-Log "接下来请完成以下配置：" "INFO"
    Write-Log "  1. 选择 AI 模型提供商并填入 API Key" "INFO"
    Write-Log "  2. 配置 QQ 机器人（和/或展开配置飞书）" "INFO"
    Write-Log "  3. 点击「保存全部配置并启动网关」" "INFO"

    $btnInstall.Enabled = $true
    $btnCheck.Enabled = $true
    Start-Sleep -Seconds 2
    $progressBar.Visible = $false
    $lblProgress.Visible = $false
}

# ==================== 配置函数 ====================

function Save-AllConfig {
    # 飞书配置
    $appId = $txtAppId.Text.Trim()
    if ($txtAppId.ForeColor -eq [System.Drawing.Color]::Gray) { $appId = "" }
    $appSecret = $txtAppSecret.Text.Trim()
    $botName = $txtBotName.Text.Trim()
    if (-not $botName) { $botName = "AI助手" }
    $feishuEnabled = ($appId -and $appSecret)

    # QQ Bot 配置
    $qqAppId = $txtQQAppId.Text.Trim()
    if ($txtQQAppId.ForeColor -eq [System.Drawing.Color]::Gray) { $qqAppId = "" }
    $qqAppSecret = $txtQQAppSecret.Text.Trim()
    $qqEnabled = ($qqAppId -and $qqAppSecret)

    # AI 模型配置
    $selectedProvider = $script:ModelProviders[$cboProvider.SelectedIndex]
    $apiKey = $txtApiKey.Text.Trim()
    if ($txtApiKey.ForeColor -eq [System.Drawing.Color]::Gray) { $apiKey = "" }

    if (-not $feishuEnabled -and -not $qqEnabled) {
        [System.Windows.Forms.MessageBox]::Show("请至少配置一个渠道（飞书或 QQ Bot）", "提示", "OK", "Warning")
        return $false
    }
    if ($feishuEnabled -and (-not $appId -or -not $appSecret)) {
        [System.Windows.Forms.MessageBox]::Show("飞书配置不完整，请填写 App ID 和 App Secret", "提示", "OK", "Warning")
        return $false
    }
    if ($qqEnabled -and (-not $qqAppId -or -not $qqAppSecret)) {
        [System.Windows.Forms.MessageBox]::Show("QQ Bot 配置不完整，请填写 AppID 和 AppSecret", "提示", "OK", "Warning")
        return $false
    }
    if (-not $apiKey -and $selectedProvider.AuthMode -eq "api_key") {
        [System.Windows.Forms.MessageBox]::Show(
            "请输入 $($selectedProvider.Name) 的 API Key`n`n获取地址：$($selectedProvider.Url)",
            "提示", "OK", "Warning"
        )
        return $false
    }

    Write-Log ">>> 正在保存全部配置 ..." "INFO"

    $configDir = if ($script:useWSL) { '~/.openclaw' } else { Join-Path $env:USERPROFILE ".openclaw" }
    $configFile = if ($script:useWSL) { "$configDir/openclaw.json" } else { Join-Path $configDir "openclaw.json" }
    $envFile = if ($script:useWSL) { "$configDir/.env" } else { Join-Path $configDir ".env" }

    if (-not $script:useWSL) {
        if (-not (Test-Path $configDir)) { New-Item -Path $configDir -ItemType Directory -Force | Out-Null }
        # 创建必要的子目录
        $sessionsDir = Join-Path $configDir "agents\main\sessions"
        if (-not (Test-Path $sessionsDir)) { New-Item -Path $sessionsDir -ItemType Directory -Force | Out-Null }
    } else {
        Run-Command "mkdir -p $configDir" -Silent
    }

    # 读取现有配置（保留 doctor --fix 添加的字段）
    $existingConfig = @{}
    if (-not $script:useWSL -and (Test-Path $configFile)) {
        try {
            $raw = [System.IO.File]::ReadAllText($configFile, [System.Text.Encoding]::UTF8)
            $existingConfig = $raw | ConvertFrom-Json -AsHashtable -ErrorAction SilentlyContinue
            if (-not $existingConfig) { $existingConfig = @{} }
        } catch { $existingConfig = @{} }
    }

    # 基于 OpenClaw 实际配置格式构建 JSON
    # 模型提供商的 baseUrl 和 api 类型映射
    $providerConfigs = @{
        "deepseek"  = @{ baseUrl = "https://api.deepseek.com/v1"; api = "openai-completions"; envKey = "DEEPSEEK_API_KEY"; models = @(@{id="deepseek-chat";name="DeepSeek Chat"},@{id="deepseek-reasoner";name="DeepSeek Reasoner"}) }
        "moonshot"  = @{ baseUrl = "https://api.moonshot.cn/v1"; api = "openai-completions"; envKey = "MOONSHOT_API_KEY"; models = @(@{id="moonshot-v1-128k";name="Moonshot 128K"}) }
        "zai"       = @{ baseUrl = "https://open.bigmodel.cn/api/paas/v4"; api = "openai-completions"; envKey = "ZHIPU_API_KEY"; models = @(@{id="glm-4";name="GLM-4"}) }
        "minimax"   = @{ baseUrl = "https://api.minimax.chat/v1"; api = "openai-completions"; envKey = "MINIMAX_API_KEY"; models = @(@{id="MiniMax-Text-01";name="MiniMax Text"}) }
        "openai"    = @{ baseUrl = "https://api.openai.com/v1"; api = "openai-completions"; envKey = "OPENAI_API_KEY"; models = @(@{id="gpt-4o";name="GPT-4o"}) }
    }

    $providerKey = $selectedProvider.Provider
    $providerCfg = $providerConfigs[$providerKey]

    # 保留现有的 gateway 配置
    $gatewayConfig = if ($existingConfig.gateway) { $existingConfig.gateway } else { @{ mode = "local" } }

    # 构建配置对象（使用 JSON 字符串直接构建，避免 PowerShell 哈希表顺序问题和编码问题）
    $modelsJson = ($providerCfg.models | ForEach-Object { "{`"id`":`"$($_.id)`",`"name`":`"$($_.name)`"}" }) -join ","

    $envKeyName = if ($providerCfg) { $providerCfg.envKey } else { "API_KEY" }

    $jsonContent = @"
{
  "gateway": {
    "mode": "local"
  },
  "models": {
    "mode": "merge",
    "providers": {
      "$providerKey": {
        "baseUrl": "$($providerCfg.baseUrl)",
        "apiKey": "`${$envKeyName}",
        "api": "$($providerCfg.api)",
        "models": [$modelsJson]
      }
    }
  },
  "agents": {
    "defaults": {
      "model": {
        "primary": "$($selectedProvider.Model)"
      },
      "memorySearch": {
        "enabled": false
      }
    }
  },
  "channels": {CHANNELS_PLACEHOLDER}
}
"@

    # 动态构建 channels 部分
    $channelParts = @()
    if ($feishuEnabled) {
        $channelParts += @"

    "feishu": {
      "enabled": true,
      "accounts": {
        "default": {
          "appId": "$appId",
          "appSecret": "$appSecret",
          "botName": "$botName"
        }
      }
    }
"@
    }
    if ($qqEnabled) {
        $channelParts += @"

    "qqbot": {
      "enabled": true,
      "appId": "$qqAppId",
      "clientSecret": "$qqAppSecret"
    }
"@
    }
    $channelsJson = $channelParts -join ","
    $jsonContent = $jsonContent -replace '\{CHANNELS_PLACEHOLDER\}', "{$channelsJson`n  }"

    # 保留 gateway.auth.token 等 doctor 生成的字段
    if ($existingConfig.'gateway' -and $existingConfig.'gateway'.'auth') {
        $tokenVal = $existingConfig.'gateway'.'auth'.'token'
        if ($tokenVal) {
            $jsonContent = $jsonContent -replace '"gateway":\s*\{[\r\n\s]*"mode":\s*"local"[\r\n\s]*\}', @"
"gateway": {
    "mode": "local",
    "auth": {
      "token": "$tokenVal"
    }
  }
"@
        }
    }

    # 写入配置文件（使用 .NET 确保 UTF-8 无 BOM，兼容性最好）
    if ($script:useWSL) {
        $escaped = $jsonContent -replace "'", "'\''"
        Run-Command "echo '$escaped' > $configFile" -Silent
    } else {
        [System.IO.File]::WriteAllText($configFile, $jsonContent, [System.Text.UTF8Encoding]::new($false))
    }

    # 写入 .env 文件（存储 API Key）
    if ($selectedProvider.AuthMode -eq "api_key" -and $apiKey -and $providerCfg) {
        $envContent = "$envKeyName=$apiKey`n"
        if ($script:useWSL) {
            Run-Command "echo '$envKeyName=$apiKey' > $envFile" -Silent
        } else {
            [System.IO.File]::WriteAllText($envFile, $envContent, [System.Text.UTF8Encoding]::new($false))
        }
        Write-Log "  API Key 已保存到 .env 文件" "INFO"
    }

    Write-Log "配置已保存！" "SUCCESS"
    if ($feishuEnabled) {
        Write-Log "  飞书 App ID:  $appId" "INFO"
        Write-Log "  飞书 Bot:     $botName" "INFO"
    }
    if ($qqEnabled) {
        Write-Log "  QQ AppID:     $qqAppId" "INFO"
    }
    Write-Log "  AI 模型:      $($selectedProvider.Model)" "INFO"
    Write-Log "  配置文件:     $configFile" "INFO"

    if ($selectedProvider.AuthMode -eq "oauth") {
        Write-Log "" "WARN"
        Write-Log "注意：$($selectedProvider.Name) 使用 OAuth 认证" "WARN"
        Write-Log "启动网关后需执行以下命令完成登录：" "WARN"
        Write-Log "  openclaw models auth login --provider $($selectedProvider.Provider) --set-default" "WARN"
    }

    # 运行 doctor --fix 让 OpenClaw 自动补全配置
    Write-Log "运行 openclaw doctor --fix ..." "INFO"
    Run-Command "openclaw doctor --fix" -Silent

    return $true
}

# ==================== 网关管理 ====================

function Start-OCGateway {
    Write-Log ">>> 正在启动 OpenClaw 网关 ..." "INFO"
    $statusResult = Run-Command "openclaw gateway status" -Silent
    if ($statusResult.Success -and $statusResult.Output -match "running") {
        Write-Log "网关已在运行中" "SUCCESS"
        $btnStartGW.Enabled = $false
        $btnStopGW.Enabled = $true
        return
    }
    if ($script:useWSL) {
        $script:gatewayProcess = Start-Process -FilePath "wsl" `
            -ArgumentList "-e", "bash", "-c", "openclaw gateway" `
            -WindowStyle Hidden -PassThru
    } else {
        $script:gatewayProcess = Start-Process -FilePath "cmd.exe" `
            -ArgumentList "/c", "openclaw gateway" `
            -WindowStyle Hidden -PassThru
    }
    Start-Sleep -Seconds 3
    [System.Windows.Forms.Application]::DoEvents()
    Write-Log "网关已启动！" "SUCCESS"
    Write-Log "现在可以在飞书中与你的 AI 助手对话了" "SUCCESS"
    $btnStartGW.Enabled = $false
    $btnStopGW.Enabled = $true

    Write-Log "正在获取网页面板 Token ..." "INFO"
    $token = ""
    $configFile = Join-Path $env:USERPROFILE ".openclaw\openclaw.json"
    if (Test-Path $configFile) {
        try {
            $configText = [System.IO.File]::ReadAllText($configFile, [System.Text.Encoding]::UTF8)
            $config = $configText | ConvertFrom-Json
            if ($config.gateway -and $config.gateway.auth -and $config.gateway.auth.token) {
                $token = $config.gateway.auth.token
            }
        } catch {
            Write-Log "  读取 Token 失败: $_" "WARN"
        }
    }

    Write-Log "正在打开 OpenClaw 网页面板 ..." "INFO"
    Start-Sleep -Seconds 2
    if ($token -and $token.Length -gt 5) {
        Start-Process "http://127.0.0.1:18789/?token=$token"
        Write-Log "已在浏览器中打开面板（自动认证）" "SUCCESS"
    } else {
        Start-Process "http://127.0.0.1:18789/"
        Write-Log "已在浏览器中打开 http://127.0.0.1:18789/" "SUCCESS"
        Write-Log "如需 Token，运行: openclaw config get gateway.auth.token" "WARN"
    }
}

function Stop-OCGateway {
    Write-Log ">>> 正在停止 OpenClaw 网关 ..." "INFO"
    Run-Command "openclaw gateway stop" -Silent
    if ($script:gatewayProcess -and -not $script:gatewayProcess.HasExited) {
        $script:gatewayProcess.Kill()
        $script:gatewayProcess = $null
    }
    Write-Log "网关已停止" "INFO"
    $btnStartGW.Enabled = $true
    $btnStopGW.Enabled = $false
}

# ==================== 卸载功能 ====================

function Do-Uninstall {
    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "确定要卸载 OpenClaw 吗？`n`n将执行以下操作：`n- 停止网关`n- 卸载 OpenClaw 及飞书插件`n- 清理 npm 全局包`n`n是否同时删除配置文件（.openclaw 目录）？`n点击「是」= 卸载并删除配置`n点击「否」= 仅卸载保留配置`n点击「取消」= 放弃卸载",
        "确认卸载 OpenClaw",
        "YesNoCancel", "Warning"
    )

    if ($confirm -eq "Cancel") {
        Write-Log "卸载已取消" "INFO"
        return
    }

    $removeConfig = ($confirm -eq "Yes")

    Write-Log "============================================" "WARN"
    Write-Log "       开始卸载 OpenClaw" "WARN"
    Write-Log "============================================" "WARN"

    # 1. 停止网关
    Write-Log ">>> 停止网关 ..." "INFO"
    Run-Command "openclaw gateway stop" -Silent
    if ($script:gatewayProcess -and -not $script:gatewayProcess.HasExited) {
        try { $script:gatewayProcess.Kill() } catch {}
        $script:gatewayProcess = $null
    }
    Get-Process -Name "node" -ErrorAction SilentlyContinue | Where-Object {
        try {
            $cmdline = (Get-CimInstance Win32_Process -Filter "ProcessId = $($_.Id)" -ErrorAction SilentlyContinue).CommandLine
            $cmdline -match "openclaw"
        } catch { $false }
    } | ForEach-Object {
        Write-Log "  终止 OpenClaw 进程 PID=$($_.Id)" "INFO"
        Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
    }
    Write-Log "  网关已停止" "SUCCESS"
    $btnStartGW.Enabled = $true
    $btnStopGW.Enabled = $false

    # 2. 卸载渠道插件
    Write-Log ">>> 卸载飞书插件 ..." "INFO"
    Run-Command "openclaw plugins uninstall @openclaw/feishu" -Silent
    Write-Log "  飞书插件已卸载" "SUCCESS"
    Write-Log ">>> 卸载 QQ Bot 插件 ..." "INFO"
    Run-Command "openclaw plugins uninstall @sliverp/qqbot" -Silent
    Write-Log "  QQ Bot 插件已卸载" "SUCCESS"

    # 3. 卸载 OpenClaw
    Write-Log ">>> 卸载 OpenClaw ..." "INFO"
    Run-Command "npm uninstall -g openclaw" -Silent
    Write-Log "  OpenClaw 已卸载" "SUCCESS"

    # 4. 清理 git 配置（移除我们添加的 insteadOf 和代理设置）
    Write-Log ">>> 清理 git 配置 ..." "INFO"
    try {
        & git config --global --unset-all "url.https://github.com/.insteadOf" 2>$null
        $gitConfigLines = & git config --global --list 2>$null
        if ($gitConfigLines) {
            $ghProxyEntries = $gitConfigLines | Where-Object { $_ -match "url\.https://.+github\.com.+\.insteadof" }
            foreach ($entry in $ghProxyEntries) {
                if ($entry -match "^(.+?)=") {
                    & git config --global --unset-all $Matches[1] 2>$null
                }
            }
        }
        Write-Log "  git 配置已清理" "SUCCESS"
    } catch {
        Write-Log "  git 清理异常（可忽略）: $_" "WARN"
    }

    # 5. 删除配置文件
    if ($removeConfig) {
        Write-Log ">>> 删除配置文件 ..." "INFO"
        $configDir = Join-Path $env:USERPROFILE ".openclaw"
        if (Test-Path $configDir) {
            Remove-Item -Path $configDir -Recurse -Force -ErrorAction SilentlyContinue
            Write-Log "  已删除 $configDir" "SUCCESS"
        }
        # 清理日志目录
        if (Test-Path "\tmp\openclaw") {
            Remove-Item -Path "\tmp\openclaw" -Recurse -Force -ErrorAction SilentlyContinue
            Write-Log "  已删除日志目录 \tmp\openclaw" "SUCCESS"
        }
    } else {
        Write-Log "  保留配置文件: $env:USERPROFILE\.openclaw" "INFO"
    }

    # 6. 清理 npm 配置（移除我们设置的镜像源和路径，恢复默认）
    Write-Log ">>> 清理 npm 配置 ..." "INFO"
    Run-Command "npm config delete registry" -Silent
    Write-Log "  npm 镜像源已恢复默认" "SUCCESS"

    # 7. 更新状态
    Update-StatusLabel $lblOpenClaw $false "" "未安装"
    Update-StatusLabel $lblFeishu $false "" "未安装"
    Update-StatusLabel $lblQQBot $false "" "未安装"

    Write-Log "============================================" "SUCCESS"
    Write-Log "  卸载完成！" "SUCCESS"
    Write-Log "============================================" "SUCCESS"
    if (-not $removeConfig) {
        Write-Log "配置文件已保留在 $env:USERPROFILE\.openclaw" "INFO"
        Write-Log "如需彻底删除，手动删除该目录即可" "INFO"
    }
    Write-Log "Node.js 未卸载（可能其他程序也在使用）" "INFO"
    Write-Log "如需卸载 Node.js，请到「设置 > 应用」中手动卸载" "INFO"
}

# ==================== 创建 GUI ====================

$font = New-Object System.Drawing.Font("Microsoft YaHei UI", 9)
$fontBold = New-Object System.Drawing.Font("Microsoft YaHei UI", 9, [System.Drawing.FontStyle]::Bold)
$fontTitle = New-Object System.Drawing.Font("Microsoft YaHei UI", 14, [System.Drawing.FontStyle]::Bold)
$fontSection = New-Object System.Drawing.Font("Microsoft YaHei UI", 10, [System.Drawing.FontStyle]::Bold)
$fontSmall = New-Object System.Drawing.Font("Microsoft YaHei UI", 8)

# --- 主窗口 ---
$mainForm = New-Object System.Windows.Forms.Form
$mainForm.Text = "OpenClaw 一键安装器 v1.2"
$mainForm.Size = New-Object System.Drawing.Size(800, 780)
$mainForm.StartPosition = "CenterScreen"
$mainForm.FormBorderStyle = "FixedSingle"
$mainForm.MaximizeBox = $false
$mainForm.BackColor = $script:Colors.BgLight
$mainForm.Font = $font

# --- 顶部标题栏 ---
$panelHeader = New-Object System.Windows.Forms.Panel
$panelHeader.Dock = "Top"
$panelHeader.Height = 50
$panelHeader.BackColor = $script:Colors.Primary

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = "OpenClaw 一键安装器"
$lblTitle.Font = $fontTitle
$lblTitle.ForeColor = [System.Drawing.Color]::White
$lblTitle.Location = New-Object System.Drawing.Point(20, 12)
$lblTitle.AutoSize = $true
$panelHeader.Controls.Add($lblTitle)

$lblSubtitle = New-Object System.Windows.Forms.Label
$lblSubtitle.Text = "让每个人都能轻松拥有 AI 助手"
$lblSubtitle.Font = $font
$lblSubtitle.ForeColor = [System.Drawing.Color]::FromArgb(180, 200, 220)
$lblSubtitle.Location = New-Object System.Drawing.Point(310, 18)
$lblSubtitle.AutoSize = $true
$panelHeader.Controls.Add($lblSubtitle)

$mainForm.Controls.Add($panelHeader)

# ==================== 第一步：环境检测与安装 ====================

$grpEnv = New-Object System.Windows.Forms.GroupBox
$grpEnv.Text = "第一步：环境检测与安装"
$grpEnv.Font = $fontSection
$grpEnv.Location = New-Object System.Drawing.Point(15, 58)
$grpEnv.Size = New-Object System.Drawing.Size(755, 130)
$grpEnv.ForeColor = $script:Colors.Primary

# 状态标签
$lblWSLT = New-Object System.Windows.Forms.Label
$lblWSLT.Text = "WSL2："
$lblWSLT.Font = $fontBold
$lblWSLT.Location = New-Object System.Drawing.Point(20, 28)
$lblWSLT.Size = New-Object System.Drawing.Size(50, 18)
$lblWSLT.ForeColor = [System.Drawing.Color]::Black
$grpEnv.Controls.Add($lblWSLT)

$lblWSL = New-Object System.Windows.Forms.Label
$lblWSL.Text = "  待检测"
$lblWSL.Font = $font
$lblWSL.Location = New-Object System.Drawing.Point(70, 28)
$lblWSL.Size = New-Object System.Drawing.Size(160, 18)
$lblWSL.ForeColor = [System.Drawing.Color]::Gray
$grpEnv.Controls.Add($lblWSL)

$lblNodeT = New-Object System.Windows.Forms.Label
$lblNodeT.Text = "Node.js："
$lblNodeT.Font = $fontBold
$lblNodeT.Location = New-Object System.Drawing.Point(240, 28)
$lblNodeT.Size = New-Object System.Drawing.Size(68, 18)
$lblNodeT.ForeColor = [System.Drawing.Color]::Black
$grpEnv.Controls.Add($lblNodeT)

$lblNode = New-Object System.Windows.Forms.Label
$lblNode.Text = "  待检测"
$lblNode.Font = $font
$lblNode.Location = New-Object System.Drawing.Point(308, 28)
$lblNode.Size = New-Object System.Drawing.Size(170, 18)
$lblNode.ForeColor = [System.Drawing.Color]::Gray
$grpEnv.Controls.Add($lblNode)

$lblOCT = New-Object System.Windows.Forms.Label
$lblOCT.Text = "OpenClaw："
$lblOCT.Font = $fontBold
$lblOCT.Location = New-Object System.Drawing.Point(20, 52)
$lblOCT.Size = New-Object System.Drawing.Size(82, 18)
$lblOCT.ForeColor = [System.Drawing.Color]::Black
$grpEnv.Controls.Add($lblOCT)

$lblOpenClaw = New-Object System.Windows.Forms.Label
$lblOpenClaw.Text = "  待检测"
$lblOpenClaw.Font = $font
$lblOpenClaw.Location = New-Object System.Drawing.Point(102, 52)
$lblOpenClaw.Size = New-Object System.Drawing.Size(170, 18)
$lblOpenClaw.ForeColor = [System.Drawing.Color]::Gray
$grpEnv.Controls.Add($lblOpenClaw)

$lblFeishu = New-Object System.Windows.Forms.Label
$lblFeishu.Visible = $false
$grpEnv.Controls.Add($lblFeishu)

$lblQQBotT = New-Object System.Windows.Forms.Label
$lblQQBotT.Text = "QQ Bot："
$lblQQBotT.Font = $fontBold
$lblQQBotT.Location = New-Object System.Drawing.Point(290, 52)
$lblQQBotT.Size = New-Object System.Drawing.Size(68, 18)
$lblQQBotT.ForeColor = [System.Drawing.Color]::Black
$grpEnv.Controls.Add($lblQQBotT)

$lblQQBot = New-Object System.Windows.Forms.Label
$lblQQBot.Text = "  待检测"
$lblQQBot.Font = $font
$lblQQBot.Location = New-Object System.Drawing.Point(358, 52)
$lblQQBot.Size = New-Object System.Drawing.Size(150, 18)
$lblQQBot.ForeColor = [System.Drawing.Color]::Gray
$grpEnv.Controls.Add($lblQQBot)

$btnCheck = New-Object System.Windows.Forms.Button
$btnCheck.Text = "检测环境"
$btnCheck.Font = $fontBold
$btnCheck.Size = New-Object System.Drawing.Size(110, 34)
$btnCheck.Location = New-Object System.Drawing.Point(500, 85)
$btnCheck.FlatStyle = "Flat"
$btnCheck.BackColor = [System.Drawing.Color]::White
$btnCheck.ForeColor = $script:Colors.Accent
$btnCheck.FlatAppearance.BorderColor = $script:Colors.Accent
$btnCheck.Cursor = [System.Windows.Forms.Cursors]::Hand
$grpEnv.Controls.Add($btnCheck)

$btnInstall = New-Object System.Windows.Forms.Button
$btnInstall.Text = "一键安装"
$btnInstall.Font = $fontBold
$btnInstall.Size = New-Object System.Drawing.Size(130, 34)
$btnInstall.Location = New-Object System.Drawing.Point(618, 85)
$btnInstall.FlatStyle = "Flat"
$btnInstall.BackColor = $script:Colors.Accent
$btnInstall.ForeColor = [System.Drawing.Color]::White
$btnInstall.FlatAppearance.BorderColor = $script:Colors.Accent
$btnInstall.Cursor = [System.Windows.Forms.Cursors]::Hand
$grpEnv.Controls.Add($btnInstall)

$progressBar = New-Object System.Windows.Forms.ProgressBar
$progressBar.Location = New-Object System.Drawing.Point(20, 92)
$progressBar.Size = New-Object System.Drawing.Size(370, 18)
$progressBar.Style = "Continuous"
$progressBar.Visible = $false
$grpEnv.Controls.Add($progressBar)

$lblProgress = New-Object System.Windows.Forms.Label
$lblProgress.Text = ""
$lblProgress.Font = $fontSmall
$lblProgress.Location = New-Object System.Drawing.Point(395, 94)
$lblProgress.Size = New-Object System.Drawing.Size(100, 16)
$lblProgress.ForeColor = $script:Colors.Accent
$lblProgress.Visible = $false
$grpEnv.Controls.Add($lblProgress)

$mainForm.Controls.Add($grpEnv)

# ==================== 第二步：AI 模型配置 ====================

$grpModel = New-Object System.Windows.Forms.GroupBox
$grpModel.Text = "第二步：选择 AI 模型（国内模型无需科学上网）"
$grpModel.Font = $fontSection
$grpModel.Location = New-Object System.Drawing.Point(15, 193)
$grpModel.Size = New-Object System.Drawing.Size(755, 115)
$grpModel.ForeColor = $script:Colors.Primary

$lblProviderT = New-Object System.Windows.Forms.Label
$lblProviderT.Text = "模型提供商："
$lblProviderT.Font = $fontBold
$lblProviderT.Location = New-Object System.Drawing.Point(20, 30)
$lblProviderT.Size = New-Object System.Drawing.Size(90, 20)
$lblProviderT.ForeColor = [System.Drawing.Color]::Black
$grpModel.Controls.Add($lblProviderT)

$cboProvider = New-Object System.Windows.Forms.ComboBox
$cboProvider.Font = $font
$cboProvider.Location = New-Object System.Drawing.Point(115, 28)
$cboProvider.Size = New-Object System.Drawing.Size(310, 25)
$cboProvider.DropDownStyle = "DropDownList"
foreach ($p in $script:ModelProviders) { $cboProvider.Items.Add($p.Name) | Out-Null }
$cboProvider.SelectedIndex = 0
$grpModel.Controls.Add($cboProvider)

$lblProviderTip = New-Object System.Windows.Forms.Label
$lblProviderTip.Text = $script:ModelProviders[0].Tip
$lblProviderTip.Font = $fontSmall
$lblProviderTip.Location = New-Object System.Drawing.Point(435, 32)
$lblProviderTip.Size = New-Object System.Drawing.Size(310, 18)
$lblProviderTip.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
$grpModel.Controls.Add($lblProviderTip)

$lblApiKeyT = New-Object System.Windows.Forms.Label
$lblApiKeyT.Text = "API Key："
$lblApiKeyT.Font = $fontBold
$lblApiKeyT.Location = New-Object System.Drawing.Point(20, 62)
$lblApiKeyT.Size = New-Object System.Drawing.Size(72, 20)
$lblApiKeyT.ForeColor = [System.Drawing.Color]::Black
$grpModel.Controls.Add($lblApiKeyT)

$txtApiKey = New-Object System.Windows.Forms.TextBox
$txtApiKey.Font = $font
$txtApiKey.Location = New-Object System.Drawing.Point(95, 60)
$txtApiKey.Size = New-Object System.Drawing.Size(330, 25)
$txtApiKey.ForeColor = [System.Drawing.Color]::Gray
$txtApiKey.Text = "sk-xxxxxxxxxxxxxxxx"
$txtApiKey.Add_GotFocus({
    if ($txtApiKey.ForeColor -eq [System.Drawing.Color]::Gray) {
        $txtApiKey.Text = ""
        $txtApiKey.ForeColor = [System.Drawing.Color]::Black
    }
})
$txtApiKey.Add_LostFocus({
    if ([string]::IsNullOrWhiteSpace($txtApiKey.Text)) {
        $txtApiKey.ForeColor = [System.Drawing.Color]::Gray
        $txtApiKey.Text = "sk-xxxxxxxxxxxxxxxx"
    }
})
$grpModel.Controls.Add($txtApiKey)

$btnGetKey = New-Object System.Windows.Forms.Button
$btnGetKey.Text = "获取 API Key"
$btnGetKey.Font = $font
$btnGetKey.Size = New-Object System.Drawing.Size(110, 28)
$btnGetKey.Location = New-Object System.Drawing.Point(435, 59)
$btnGetKey.FlatStyle = "Flat"
$btnGetKey.BackColor = [System.Drawing.Color]::White
$btnGetKey.ForeColor = $script:Colors.Primary
$btnGetKey.FlatAppearance.BorderColor = $script:Colors.Primary
$btnGetKey.Cursor = [System.Windows.Forms.Cursors]::Hand
$grpModel.Controls.Add($btnGetKey)

$lblModelInfo = New-Object System.Windows.Forms.Label
$lblModelInfo.Text = "推荐：DeepSeek 性价比最高 | 通义千问有免费额度 | 智谱/Kimi/MiniMax 均为国内直连"
$lblModelInfo.Font = $fontSmall
$lblModelInfo.Location = New-Object System.Drawing.Point(20, 93)
$lblModelInfo.Size = New-Object System.Drawing.Size(720, 16)
$lblModelInfo.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
$grpModel.Controls.Add($lblModelInfo)

$mainForm.Controls.Add($grpModel)

# ==================== 第三步：配置 QQ 机器人 ====================

$grpQQ = New-Object System.Windows.Forms.GroupBox
$grpQQ.Text = "第三步：配置 QQ 机器人"
$grpQQ.Font = $fontSection
$grpQQ.Location = New-Object System.Drawing.Point(15, 313)
$grpQQ.Size = New-Object System.Drawing.Size(755, 95)
$grpQQ.ForeColor = $script:Colors.Primary

$lblQQAppIdL = New-Object System.Windows.Forms.Label
$lblQQAppIdL.Text = "AppID："
$lblQQAppIdL.Font = $fontBold
$lblQQAppIdL.Location = New-Object System.Drawing.Point(20, 30)
$lblQQAppIdL.Size = New-Object System.Drawing.Size(60, 20)
$lblQQAppIdL.ForeColor = [System.Drawing.Color]::Black
$grpQQ.Controls.Add($lblQQAppIdL)

$txtQQAppId = New-Object System.Windows.Forms.TextBox
$txtQQAppId.Font = $font
$txtQQAppId.Location = New-Object System.Drawing.Point(82, 28)
$txtQQAppId.Size = New-Object System.Drawing.Size(200, 25)
$txtQQAppId.ForeColor = [System.Drawing.Color]::Gray
$txtQQAppId.Text = "QQ Bot AppID"
$txtQQAppId.Add_GotFocus({
    if ($txtQQAppId.ForeColor -eq [System.Drawing.Color]::Gray) {
        $txtQQAppId.Text = ""
        $txtQQAppId.ForeColor = [System.Drawing.Color]::Black
    }
})
$txtQQAppId.Add_LostFocus({
    if ([string]::IsNullOrWhiteSpace($txtQQAppId.Text)) {
        $txtQQAppId.ForeColor = [System.Drawing.Color]::Gray
        $txtQQAppId.Text = "QQ Bot AppID"
    }
})
$grpQQ.Controls.Add($txtQQAppId)

$lblQQSecretL = New-Object System.Windows.Forms.Label
$lblQQSecretL.Text = "AppSecret："
$lblQQSecretL.Font = $fontBold
$lblQQSecretL.Location = New-Object System.Drawing.Point(300, 30)
$lblQQSecretL.Size = New-Object System.Drawing.Size(85, 20)
$lblQQSecretL.ForeColor = [System.Drawing.Color]::Black
$grpQQ.Controls.Add($lblQQSecretL)

$txtQQAppSecret = New-Object System.Windows.Forms.TextBox
$txtQQAppSecret.Font = $font
$txtQQAppSecret.Location = New-Object System.Drawing.Point(388, 28)
$txtQQAppSecret.Size = New-Object System.Drawing.Size(250, 25)
$txtQQAppSecret.UseSystemPasswordChar = $true
$grpQQ.Controls.Add($txtQQAppSecret)

$chkShowQQSecret = New-Object System.Windows.Forms.CheckBox
$chkShowQQSecret.Text = "显示"
$chkShowQQSecret.Font = $font
$chkShowQQSecret.Location = New-Object System.Drawing.Point(645, 30)
$chkShowQQSecret.Size = New-Object System.Drawing.Size(55, 20)
$chkShowQQSecret.ForeColor = [System.Drawing.Color]::Black
$chkShowQQSecret.Add_CheckedChanged({
    $txtQQAppSecret.UseSystemPasswordChar = -not $chkShowQQSecret.Checked
})
$grpQQ.Controls.Add($chkShowQQSecret)

$btnOpenQQ = New-Object System.Windows.Forms.Button
$btnOpenQQ.Text = "打开 QQ 开放平台"
$btnOpenQQ.Font = $font
$btnOpenQQ.Size = New-Object System.Drawing.Size(140, 30)
$btnOpenQQ.Location = New-Object System.Drawing.Point(20, 58)
$btnOpenQQ.FlatStyle = "Flat"
$btnOpenQQ.BackColor = [System.Drawing.Color]::White
$btnOpenQQ.ForeColor = $script:Colors.Primary
$btnOpenQQ.FlatAppearance.BorderColor = $script:Colors.Primary
$btnOpenQQ.Cursor = [System.Windows.Forms.Cursors]::Hand
$grpQQ.Controls.Add($btnOpenQQ)

$lblQQTip = New-Object System.Windows.Forms.Label
$lblQQTip.Text = "在 QQ 开放平台创建机器人应用（非小程序），获取 AppID 和 AppSecret"
$lblQQTip.Font = $fontSmall
$lblQQTip.Location = New-Object System.Drawing.Point(170, 65)
$lblQQTip.Size = New-Object System.Drawing.Size(500, 18)
$lblQQTip.ForeColor = [System.Drawing.Color]::Gray
$grpQQ.Controls.Add($lblQQTip)

$mainForm.Controls.Add($grpQQ)

# ==================== 第四步：飞书应用配置（折叠） ====================

$script:feishuExpanded = $false
$script:feishuCollapsedHeight = 35
$script:feishuExpandedHeight = 195

$grpFeishu = New-Object System.Windows.Forms.GroupBox
$grpFeishu.Text = "第四步：配置飞书应用（可选）  ▶ 点击展开"
$grpFeishu.Font = $fontSection
$grpFeishu.Location = New-Object System.Drawing.Point(15, 413)
$grpFeishu.Size = New-Object System.Drawing.Size(755, $script:feishuCollapsedHeight)
$grpFeishu.ForeColor = [System.Drawing.Color]::Gray
$grpFeishu.Cursor = [System.Windows.Forms.Cursors]::Hand

$lblAppIdL = New-Object System.Windows.Forms.Label
$lblAppIdL.Text = "App ID："
$lblAppIdL.Font = $fontBold
$lblAppIdL.Location = New-Object System.Drawing.Point(20, 30)
$lblAppIdL.Size = New-Object System.Drawing.Size(75, 20)
$lblAppIdL.ForeColor = [System.Drawing.Color]::Black
$grpFeishu.Controls.Add($lblAppIdL)

$txtAppId = New-Object System.Windows.Forms.TextBox
$txtAppId.Font = $font
$txtAppId.Location = New-Object System.Drawing.Point(100, 28)
$txtAppId.Size = New-Object System.Drawing.Size(330, 25)
$txtAppId.ForeColor = [System.Drawing.Color]::Gray
$txtAppId.Text = "cli_xxxxxxxxxxxxxxxx"
$txtAppId.Add_GotFocus({
    if ($txtAppId.ForeColor -eq [System.Drawing.Color]::Gray) {
        $txtAppId.Text = ""
        $txtAppId.ForeColor = [System.Drawing.Color]::Black
    }
})
$txtAppId.Add_LostFocus({
    if ([string]::IsNullOrWhiteSpace($txtAppId.Text)) {
        $txtAppId.ForeColor = [System.Drawing.Color]::Gray
        $txtAppId.Text = "cli_xxxxxxxxxxxxxxxx"
    }
})
$grpFeishu.Controls.Add($txtAppId)

$lblSecretL = New-Object System.Windows.Forms.Label
$lblSecretL.Text = "App Secret："
$lblSecretL.Font = $fontBold
$lblSecretL.Location = New-Object System.Drawing.Point(20, 62)
$lblSecretL.Size = New-Object System.Drawing.Size(95, 20)
$lblSecretL.ForeColor = [System.Drawing.Color]::Black
$grpFeishu.Controls.Add($lblSecretL)

$txtAppSecret = New-Object System.Windows.Forms.TextBox
$txtAppSecret.Font = $font
$txtAppSecret.Location = New-Object System.Drawing.Point(118, 60)
$txtAppSecret.Size = New-Object System.Drawing.Size(312, 25)
$grpFeishu.Controls.Add($txtAppSecret)

$chkShowSecret = New-Object System.Windows.Forms.CheckBox
$chkShowSecret.Text = "显示"
$chkShowSecret.Font = $font
$chkShowSecret.Location = New-Object System.Drawing.Point(435, 62)
$chkShowSecret.Size = New-Object System.Drawing.Size(55, 20)
$chkShowSecret.ForeColor = [System.Drawing.Color]::Black
$chkShowSecret.Add_CheckedChanged({
    $txtAppSecret.UseSystemPasswordChar = -not $chkShowSecret.Checked
})
$grpFeishu.Controls.Add($chkShowSecret)

$lblBotL = New-Object System.Windows.Forms.Label
$lblBotL.Text = "Bot Name："
$lblBotL.Font = $fontBold
$lblBotL.Location = New-Object System.Drawing.Point(20, 94)
$lblBotL.Size = New-Object System.Drawing.Size(82, 20)
$lblBotL.ForeColor = [System.Drawing.Color]::Black
$grpFeishu.Controls.Add($lblBotL)

$txtBotName = New-Object System.Windows.Forms.TextBox
$txtBotName.Font = $font
$txtBotName.Location = New-Object System.Drawing.Point(105, 92)
$txtBotName.Size = New-Object System.Drawing.Size(325, 25)
$txtBotName.Text = "AI助手"
$grpFeishu.Controls.Add($txtBotName)

$btnOpenFeishu = New-Object System.Windows.Forms.Button
$btnOpenFeishu.Text = "打开飞书开放平台"
$btnOpenFeishu.Font = $font
$btnOpenFeishu.Size = New-Object System.Drawing.Size(135, 30)
$btnOpenFeishu.Location = New-Object System.Drawing.Point(20, 124)
$btnOpenFeishu.FlatStyle = "Flat"
$btnOpenFeishu.BackColor = [System.Drawing.Color]::White
$btnOpenFeishu.ForeColor = $script:Colors.Primary
$btnOpenFeishu.FlatAppearance.BorderColor = $script:Colors.Primary
$btnOpenFeishu.Cursor = [System.Windows.Forms.Cursors]::Hand
$grpFeishu.Controls.Add($btnOpenFeishu)

$btnCopyPerm = New-Object System.Windows.Forms.Button
$btnCopyPerm.Text = "复制权限 JSON"
$btnCopyPerm.Font = $font
$btnCopyPerm.Size = New-Object System.Drawing.Size(120, 30)
$btnCopyPerm.Location = New-Object System.Drawing.Point(163, 124)
$btnCopyPerm.FlatStyle = "Flat"
$btnCopyPerm.BackColor = [System.Drawing.Color]::White
$btnCopyPerm.ForeColor = $script:Colors.Primary
$btnCopyPerm.FlatAppearance.BorderColor = $script:Colors.Primary
$btnCopyPerm.Cursor = [System.Windows.Forms.Cursors]::Hand
$grpFeishu.Controls.Add($btnCopyPerm)

$btnInstallFeishu = New-Object System.Windows.Forms.Button
$btnInstallFeishu.Text = "安装飞书插件"
$btnInstallFeishu.Font = $font
$btnInstallFeishu.Size = New-Object System.Drawing.Size(120, 30)
$btnInstallFeishu.Location = New-Object System.Drawing.Point(291, 124)
$btnInstallFeishu.FlatStyle = "Flat"
$btnInstallFeishu.BackColor = $script:Colors.Accent
$btnInstallFeishu.ForeColor = [System.Drawing.Color]::White
$btnInstallFeishu.FlatAppearance.BorderColor = $script:Colors.Accent
$btnInstallFeishu.Cursor = [System.Windows.Forms.Cursors]::Hand
$grpFeishu.Controls.Add($btnInstallFeishu)

$lblFeishuTip = New-Object System.Windows.Forms.Label
$lblFeishuTip.Text = "在飞书开放平台创建「企业自建应用」`n获取 App ID 和 App Secret`n记得启用机器人能力并配置事件订阅"
$lblFeishuTip.Font = $fontSmall
$lblFeishuTip.Location = New-Object System.Drawing.Point(500, 28)
$lblFeishuTip.Size = New-Object System.Drawing.Size(245, 55)
$lblFeishuTip.ForeColor = [System.Drawing.Color]::Gray
$grpFeishu.Controls.Add($lblFeishuTip)

# 飞书内部控件初始隐藏
$script:feishuInnerControls = @($lblAppIdL, $txtAppId, $lblSecretL, $txtAppSecret, $chkShowSecret, $lblBotL, $txtBotName, $btnOpenFeishu, $btnCopyPerm, $btnInstallFeishu, $lblFeishuTip)
foreach ($ctrl in $script:feishuInnerControls) { $ctrl.Visible = $false }

$mainForm.Controls.Add($grpFeishu)

# ==================== 第五步：保存并启动 ====================

$grpGateway = New-Object System.Windows.Forms.GroupBox
$grpGateway.Text = "第五步：保存配置并启动"
$grpGateway.Font = $fontSection
$grpGateway.Location = New-Object System.Drawing.Point(15, 453)
$grpGateway.Size = New-Object System.Drawing.Size(755, 55)
$grpGateway.ForeColor = $script:Colors.Primary

$btnSaveAndStart = New-Object System.Windows.Forms.Button
$btnSaveAndStart.Text = "保存全部配置并启动网关"
$btnSaveAndStart.Font = $fontBold
$btnSaveAndStart.Size = New-Object System.Drawing.Size(210, 32)
$btnSaveAndStart.Location = New-Object System.Drawing.Point(20, 18)
$btnSaveAndStart.FlatStyle = "Flat"
$btnSaveAndStart.BackColor = $script:Colors.Accent
$btnSaveAndStart.ForeColor = [System.Drawing.Color]::White
$btnSaveAndStart.FlatAppearance.BorderColor = $script:Colors.Accent
$btnSaveAndStart.Cursor = [System.Windows.Forms.Cursors]::Hand
$grpGateway.Controls.Add($btnSaveAndStart)

$btnStartGW = New-Object System.Windows.Forms.Button
$btnStartGW.Text = "启动网关"
$btnStartGW.Font = $font
$btnStartGW.Size = New-Object System.Drawing.Size(100, 32)
$btnStartGW.Location = New-Object System.Drawing.Point(530, 18)
$btnStartGW.FlatStyle = "Flat"
$btnStartGW.BackColor = $script:Colors.Success
$btnStartGW.ForeColor = [System.Drawing.Color]::White
$btnStartGW.FlatAppearance.BorderColor = $script:Colors.Success
$btnStartGW.Cursor = [System.Windows.Forms.Cursors]::Hand
$grpGateway.Controls.Add($btnStartGW)

$btnStopGW = New-Object System.Windows.Forms.Button
$btnStopGW.Text = "停止网关"
$btnStopGW.Font = $font
$btnStopGW.Size = New-Object System.Drawing.Size(100, 32)
$btnStopGW.Location = New-Object System.Drawing.Point(638, 18)
$btnStopGW.FlatStyle = "Flat"
$btnStopGW.BackColor = $script:Colors.Error
$btnStopGW.ForeColor = [System.Drawing.Color]::White
$btnStopGW.FlatAppearance.BorderColor = $script:Colors.Error
$btnStopGW.Cursor = [System.Windows.Forms.Cursors]::Hand
$btnStopGW.Enabled = $false
$grpGateway.Controls.Add($btnStopGW)

$btnUninstall = New-Object System.Windows.Forms.Button
$btnUninstall.Text = "卸载 OpenClaw"
$btnUninstall.Font = $font
$btnUninstall.Size = New-Object System.Drawing.Size(120, 32)
$btnUninstall.Location = New-Object System.Drawing.Point(270, 18)
$btnUninstall.FlatStyle = "Flat"
$btnUninstall.BackColor = [System.Drawing.Color]::White
$btnUninstall.ForeColor = $script:Colors.Error
$btnUninstall.FlatAppearance.BorderColor = $script:Colors.Error
$btnUninstall.Cursor = [System.Windows.Forms.Cursors]::Hand
$grpGateway.Controls.Add($btnUninstall)

$mainForm.Controls.Add($grpGateway)

# ==================== 安装日志 ====================

$grpLog = New-Object System.Windows.Forms.GroupBox
$grpLog.Text = "安装日志"
$grpLog.Font = $fontSection
$grpLog.Location = New-Object System.Drawing.Point(15, 513)
$grpLog.Size = New-Object System.Drawing.Size(755, 220)
$grpLog.ForeColor = $script:Colors.Primary

$logBox = New-Object System.Windows.Forms.RichTextBox
$logBox.Location = New-Object System.Drawing.Point(10, 22)
$logBox.Size = New-Object System.Drawing.Size(733, 185)
$logBox.BackColor = $script:Colors.BgDark
$logBox.ForeColor = $script:Colors.LogGreen
$logBox.Font = New-Object System.Drawing.Font("Consolas", 9)
$logBox.ReadOnly = $true
$logBox.BorderStyle = "None"
$logBox.ScrollBars = "Vertical"
$grpLog.Controls.Add($logBox)

$mainForm.Controls.Add($grpLog)

# ==================== 事件绑定 ====================

$btnCheck.Add_Click({ Do-EnvironmentCheck })
$btnInstall.Add_Click({ Do-OneClickInstall })

$cboProvider.Add_SelectedIndexChanged({
    $idx = $cboProvider.SelectedIndex
    $provider = $script:ModelProviders[$idx]
    $lblProviderTip.Text = $provider.Tip
    if ($provider.AuthMode -eq "oauth") {
        $txtApiKey.Enabled = $false
        $txtApiKey.Text = "此提供商使用 OAuth 登录，无需 API Key"
        $txtApiKey.ForeColor = [System.Drawing.Color]::Gray
        $lblApiKeyT.Text = "认证："
    } else {
        $txtApiKey.Enabled = $true
        if ($txtApiKey.ForeColor -eq [System.Drawing.Color]::Gray) {
            $txtApiKey.Text = "sk-xxxxxxxxxxxxxxxx"
        }
        $lblApiKeyT.Text = "API Key："
    }
})

$btnGetKey.Add_Click({
    $idx = $cboProvider.SelectedIndex
    $provider = $script:ModelProviders[$idx]
    Start-Process $provider.Url
    Write-Log "已打开 $($provider.Name) 的 Key 获取页面" "INFO"
    if ($provider.AuthMode -eq "oauth") {
        Write-Log "此提供商使用 OAuth 设备码认证，启动网关后需执行命令登录" "WARN"
    } else {
        Write-Log "请注册/登录后创建 API Key，复制粘贴到上方输入框" "INFO"
    }
})

$btnOpenFeishu.Add_Click({
    Start-Process "https://open.feishu.cn/app"
    Write-Log "已打开飞书开放平台" "INFO"
    Write-Log "请创建「企业自建应用」，获取 App ID 和 App Secret" "INFO"
})

$btnInstallFeishu.Add_Click({
    $btnInstallFeishu.Enabled = $false
    $btnInstallFeishu.Text = "安装中..."
    [System.Windows.Forms.Application]::DoEvents()
    $ok = Install-FeishuPlugin
    if ($ok) {
        $btnInstallFeishu.Text = "飞书插件已安装"
        $btnInstallFeishu.BackColor = $script:Colors.Success
        $btnInstallFeishu.FlatAppearance.BorderColor = $script:Colors.Success
        Update-StatusLabel $lblFeishu $true "已安装" ""
    } else {
        $btnInstallFeishu.Text = "安装失败，重试"
        $btnInstallFeishu.Enabled = $true
    }
})

# 飞书区域展开/折叠
$script:toggleFeishu = {
    [int]$diff = $script:feishuExpandedHeight - $script:feishuCollapsedHeight
    if ($script:feishuExpanded) {
        $script:feishuExpanded = $false
        $grpFeishu.Size = New-Object System.Drawing.Size(755, $script:feishuCollapsedHeight)
        $grpFeishu.Text = "第四步：配置飞书应用（可选）  ▶ 点击展开"
        $grpFeishu.ForeColor = [System.Drawing.Color]::Gray
        foreach ($ctrl in $script:feishuInnerControls) { $ctrl.Visible = $false }
        [int]$gwY = $grpGateway.Location.Y - $diff
        [int]$logY = $grpLog.Location.Y - $diff
        [int]$fmH = $mainForm.Size.Height - $diff
        $grpGateway.Location = New-Object System.Drawing.Point(15, $gwY)
        $grpLog.Location = New-Object System.Drawing.Point(15, $logY)
        $mainForm.Size = New-Object System.Drawing.Size(800, $fmH)
    } else {
        $script:feishuExpanded = $true
        $grpFeishu.Size = New-Object System.Drawing.Size(755, $script:feishuExpandedHeight)
        $grpFeishu.Text = "第四步：配置飞书应用（可选）  ▼ 点击折叠"
        $grpFeishu.ForeColor = $script:Colors.Primary
        foreach ($ctrl in $script:feishuInnerControls) { $ctrl.Visible = $true }
        [int]$gwY = $grpGateway.Location.Y + $diff
        [int]$logY = $grpLog.Location.Y + $diff
        [int]$fmH = $mainForm.Size.Height + $diff
        $grpGateway.Location = New-Object System.Drawing.Point(15, $gwY)
        $grpLog.Location = New-Object System.Drawing.Point(15, $logY)
        $mainForm.Size = New-Object System.Drawing.Size(800, $fmH)
        if (Test-FeishuPlugin) {
            $btnInstallFeishu.Text = "飞书插件已安装"
            $btnInstallFeishu.Enabled = $false
            $btnInstallFeishu.BackColor = $script:Colors.Success
            $btnInstallFeishu.FlatAppearance.BorderColor = $script:Colors.Success
            Update-StatusLabel $lblFeishu $true "已安装" ""
        } else {
            $btnInstallFeishu.Text = "安装飞书插件"
            $btnInstallFeishu.Enabled = $true
            $btnInstallFeishu.BackColor = $script:Colors.Accent
            $btnInstallFeishu.FlatAppearance.BorderColor = $script:Colors.Accent
        }
    }
}
$grpFeishu.Add_Click($script:toggleFeishu)

$btnCopyPerm.Add_Click({
    [System.Windows.Forms.Clipboard]::SetText($script:permissionsJSON)
    Write-Log "权限 JSON 已复制到剪贴板" "SUCCESS"
    [System.Windows.Forms.MessageBox]::Show(
        "权限配置 JSON 已复制到剪贴板！`n`n请在飞书开放平台中：`n1. 进入「权限管理」页面`n2. 点击「批量导入」`n3. 粘贴并导入",
        "复制成功", "OK", "Information"
    )
})

$btnSaveAndStart.Add_Click({
    $ok = Save-AllConfig
    if ($ok) {
        Start-Sleep -Milliseconds 500
        Start-OCGateway
    }
})

$btnStartGW.Add_Click({ Start-OCGateway })
$btnStopGW.Add_Click({ Stop-OCGateway })
$btnUninstall.Add_Click({ Do-Uninstall })

$btnOpenQQ.Add_Click({
    Start-Process "https://q.qq.com"
    Write-Log "已打开 QQ 开放平台" "INFO"
    Write-Log "请创建「机器人」应用（不是小程序），获取 AppID 和 AppSecret" "INFO"
})

$mainForm.Add_FormClosing({
    if ($script:gatewayProcess -and -not $script:gatewayProcess.HasExited) {
        $result = [System.Windows.Forms.MessageBox]::Show(
            "OpenClaw 网关正在运行中，关闭将同时停止网关。`n确定退出吗？",
            "确认退出", "YesNo", "Question"
        )
        if ($result -eq "No") {
            $_.Cancel = $true
            return
        }
        Stop-OCGateway
    }
})

# ==================== 启动 ====================

$mainForm.Add_Shown({
    Write-Log "欢迎使用 OpenClaw 一键安装器 v1.2！" "SUCCESS"
    Write-Log "" "INFO"
    Write-Log "五步完成配置：" "INFO"
    Write-Log "  1. 点击「检测环境」->「一键安装」" "INFO"
    Write-Log "  2. 选择 AI 模型提供商，填入 API Key" "INFO"
    Write-Log "     推荐 DeepSeek（便宜好用）或 通义千问（有免费额度）" "WARN"
    Write-Log "  3. 配置 QQ 机器人（推荐，配置简单）" "INFO"
    Write-Log "  4. 配置飞书应用（可选，点击展开）" "INFO"
    Write-Log "  5. 点击「保存全部配置并启动网关」" "INFO"
    Write-Log "" "INFO"
    Write-Log "首次使用请先点击「检测环境」按钮" "WARN"
})

[System.Windows.Forms.Application]::Run($mainForm)
